namespace Stations.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=.;Database=Stations;Trusted_Connection=True";
	}
}