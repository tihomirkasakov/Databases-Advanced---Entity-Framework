﻿namespace Stations.Models.Enums
{
    public enum TrainType
    {
        HighSpeed,
        LongDistance,
        Freight
    }
}
