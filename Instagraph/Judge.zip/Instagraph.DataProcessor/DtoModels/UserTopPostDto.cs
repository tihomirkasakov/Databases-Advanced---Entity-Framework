﻿namespace Instagraph.DataProcessor.DtoModels
{
    class UserTopPostDto
    {
        public string Username { get; set; }
        public int MostComments { get; set; }
    }
}
